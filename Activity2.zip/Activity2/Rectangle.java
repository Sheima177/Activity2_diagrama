package Activity2;


	public class Rectangle {
	    private int positionX;
	    private int positionY;
	    private int height;
	    private int width;
	    private int thicknessLine;

	    // Constructor
	    public Rectangle(int positionX, int positionY, int height, int width, int thicknessLine) {
	        this.setPositionX(positionX);
	        this.setPositionY(positionY);
	        this.setHeight(height);
	        this.setWidth(width);
	        this.setThicknessLine(thicknessLine);
	    }

	    // Mètode per dibuixar el rectangle
	    public void draw() {
	        // Implementa la lògica per dibuixar el rectangle
	    }

		public int getPositionX() {
			return positionX;
		}

		public void setPositionX(int positionX) {
			this.positionX = positionX;
		}

		public int getPositionY() {
			return positionY;
		}

		public void setPositionY(int positionY) {
			this.positionY = positionY;
		}

		public int getHeight() {
			return height;
		}

		public void setHeight(int height) {
			this.height = height;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		public int getThicknessLine() {
			return thicknessLine;
		}

		public void setThicknessLine(int thicknessLine) {
			this.thicknessLine = thicknessLine;
		}
	}