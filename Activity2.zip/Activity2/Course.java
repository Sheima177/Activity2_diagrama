package Activity2;

import java.util.List;

public class Course {
    private List<Alumn> students;

    // Constructor
    public Course() {
        // Inicialitza la llista d'alumnes
    }

    // Mètode per comptar els estudiants
    public int countStudents() {
        return students.size();
    }
}
